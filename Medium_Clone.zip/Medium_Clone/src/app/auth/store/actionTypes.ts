export enum ActionTypes {
    REGISTER = '[Auth] Register',
    REGISTER_SUCCESS = '[Auth] Register success',
    REGISTER_FAILURE = '[Auth] Register failure'
}