import { CurrentUserInterface } from "src/app/shared/types/currentUser.interface";

export interface AuthResponseInterface{
    user: CurrentUserInterface
}