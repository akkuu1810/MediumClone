import { AuthStateInterface } from "src/app/auth/types/authState.interface";

 export interface AppStateInterface {
    auth: AuthStateInterface
 }