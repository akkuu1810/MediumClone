export interface BackendErrorsInterface {
    [Key: string]: String[]
    
}