export const environment = {
  production: true,
  apiUrl: 'https://conduit.productionready.io/api'
};
